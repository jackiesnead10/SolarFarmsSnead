﻿using System;
using Gomoku.Players;
using Gomoku.Game;
namespace Gomoku
{
    public class workflow
    {

        public workflow()
        {
            //1.welcome to gomuku!(add title prmpt)
            Console.WriteLine("Welcome to Gomoku!");
            Console.WriteLine("==================");

            //2. prompt the user for Player 1 if it is human or Random player
            // loop for player 2???
            


        }
            public static IPlayer[] setUpPlayer()
            { 
                int select1;
                int select2;

                IPlayer player1;
                IPlayer player2;
                bool correctinput = true;
                IPlayer[] players = new IPlayer[2];

            while (correctinput)
                {
                    
                    
                        Console.Write("Player 1 is:\n");
                        Console.Write("1.Human\n");
                        Console.Write("2.Random Player\n");
                        Console.Write("Select [1-2]: \n");

                        select1 = int.Parse(Console.ReadLine());
                     if(select1 == 1)
                     {
                        Console.Write("Player 1, enter your name:");
                        player1 = new HumanPlayer(Console.ReadLine());
                        players[0] = player1;
                        correctinput = false;
                     }
                     else if (select1 == 2)
                    {
                        player1 = new RandomPlayer();
                        players[0] = player1;
                        correctinput = false;
                    }
                     else
                     {
                        Console.WriteLine("This is not a valid option, please select 1 or 2.");
                     }
                   
                }
            correctinput = true;
               while (correctinput)
               {
                        Console.Write("Player 2 is:\n");
                        Console.Write("1.Human\n");
                        Console.Write("2.Random Player\n");
                        Console.Write("Select [1-2]: \n");

                        select2 = int.Parse(Console.ReadLine());

                        if (select2 == 1)
                        {
                            Console.Write("Player 2, enter your name:");
                            player2 = new HumanPlayer(Console.ReadLine());
                            players[1] = player2;
                            correctinput = false;
                        }
                        else if(select2 == 2)
                        {
                            player2 = new RandomPlayer();
                            players[1] = player2;
                            correctinput = false;
                        }
                        else
                        {
                            Console.WriteLine("This is not a valid option, please select 1 or 2.");
                        }
                    

                }


            return players;




            }




        public static void randomizer() {

            //switch case for 1-2??

            //i. select 1-2 for player and random player
            //ii. enter player 1 name:
            //validation check


            //3.Prompt the user for Player 2 if it is human or random player
            //i.select 1-2 for player and random player
            //ii. enter player 2 name:
            //validation check


            //4. randomize players to see who goes first
            Console.WriteLine("Gomoku!");


            Random rand = new Random();


            Console.WriteLine("Your Random Number is: " + rand.Next(1, 3));
            Console.WriteLine(new Random() + "goes first");
        }

            //5. Game play, first player prompt;

            public static void gameStart (IPlayer[] players)
            {
            Console.WriteLine(players[0].Name + " " + players[1].Name);
                GomokuEngine game = new GomokuEngine(players[0], players[1]);
            int row;
            int column;
            char[,] board = new char[GomokuEngine.WIDTH, GomokuEngine.WIDTH];
            for (int i = 0; i < GomokuEngine.WIDTH; i++)
            {
                for (int k = 0; k < GomokuEngine.WIDTH; k++)
                {
                  board[i, k] = '-';
                }
            }

            while (game.IsOver == false)
                {

                if (game.Current.GenerateMove(game.Stones) == null)
                {
                    Console.WriteLine(game.Current.Name + "'s Turn!");
                    Console.WriteLine("Enter a Row: ");
                    row = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter a Column: ");
                    column = int.Parse(Console.ReadLine());
                    Stone move = new Stone(row, column, game.IsBlacksTurn);
                    Result result = game.Place(move);
                    Console.WriteLine(result.Message);
                }
                else
                {
                    Console.WriteLine(game.Current.Name + "'s Turn!");
                    Stone move = game.Current.GenerateMove(game.Stones);
                    Result result = game.Place(move);
                    Console.WriteLine(result.Message);
                }

                if(game.Stones[game.Stones.Length-1].IsBlack == true)
                {
                    board[game.Stones[game.Stones.Length - 1].Row-1, game.Stones[game.Stones.Length - 1].Column-1] = 'X';
                }
                else
                {
                    board[game.Stones[game.Stones.Length - 1].Row-1, game.Stones[game.Stones.Length - 1].Column-1] = 'O';
                }


                displayBoards(game, board);
                
                }
            }       
        public static void displayBoards(GomokuEngine game, char[,] board)
        {

            Console.WriteLine("   01 02 03 04 05 06 07 08 09 10 11 12 13 14 15");
            for (int i = 0; i < GomokuEngine.WIDTH; i++)
            {
                if (i+1 < 10)
                {
                    Console.Write("0" + (i + 1) + "  ");
                }
                else
                {
                    Console.Write((i + 1) + "  ");
                }
                for (int k = 0; k < GomokuEngine.WIDTH; k++)
                {
                    Console.Write(board[i,k] + "  ");
                }
                Console.WriteLine();
            }


        }

            //i. enter a row and column
            //ii. show board 15 x 15 and player position
            //iii. second player turn.


            //6. Make sure player turns cannot overlap with eachother
            //i.validationcheck
            //check gomokuengine


            //7. Player that gets 5 marks in a row or column or diagonal to win
            //i. a tie can happen
            //ii. if a player wins, comment Winner!
            //iii. prompt player if they want to play again if not terminate.
            //validation check

        
    }
}
