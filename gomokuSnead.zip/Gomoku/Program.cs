﻿using System;
using Gomoku.Players;

namespace Gomoku
{
    class Program
    {
        static void Main(string[] args)
        {
            bool play = true;
            System.Console.WriteLine("Gomoku!");
          //  IPlayer[] players = workflow.setUpPlayer();

            while (play)
            {
                IPlayer[] players = workflow.setUpPlayer();
                workflow.gameStart(players);

                Console.WriteLine("Do you want to play again?");
                Console.WriteLine("Exit [y/n]: ");
                if (Console.ReadLine() == "y")
                {
                    Console.WriteLine("goodbye!");
                    play = false;
                }
                
            }
            

        }
    }
}
