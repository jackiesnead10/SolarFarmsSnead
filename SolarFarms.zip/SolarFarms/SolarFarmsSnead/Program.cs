﻿using System;
using SolarFarms.CORE;
using SolarFarms.DAL;
using SolarFarms.BLL;


namespace SolarFarms
{
    class Program
    {
       static void Main(string[] args)
        {
            //make solar.csv
            //filetaskrepository is which solar object??
           
           
            SolarFarmsController controller = new SolarFarmsController(SolarService);
            controller.Run();

        }
    }
    }
}
