﻿using System;
using SolarFarms.CORE;
using SolarFarms.BLL;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolarFarms.UI;
using SolarFarms.DAL;
namespace SolarFarms.SolarFarms.UI
{
    public class SolarFarmsController
    {
        private SolarService _solarService;
        public SolarRepository _solarRepository = new SolarRepository();
        public SolarFarmsController(SolarService solarService)
        {
            _solarService = solarService;
        }
        public void Run()
        {
            // Keep the application running, display a menu for CRUD of tasks
            ConsoleIO.Display("Welcome to the Solar Farm.");
            ConsoleIO.Display("===========================");
            do
            {


                int choice = ConsoleIO.PromptInt("0. Exit\n1. Add Panel\n2. View Panels\n3. Find Panel\n4. Update Panel\n5. Delete Panel", 0, 5);
                switch (choice)
                {
                    case 0:
                        ConsoleIO.Display("Good bye");
                        return;
                    case 1:
                        AddPanel();
                        break;
                    case 2:
                        ViewBySection();
                        break;
                    case 3:
                        FindPanel();
                        break;
                    case 4:
                        UpdatePanel();
                        break;
                    case 5:
                        DeletePanel();
                        break;
                }
            } while (true);
        }

        private void FindPanel()
        {
            ConsoleIO.Display("Enter Panel location:");
            String SectionKey = ConsoleIO.PromptUser("Enter Section: ");
            int row = ConsoleIO.PromptInt("Enter Row: ");
            int column = ConsoleIO.PromptInt("Enter Column: ");
            Result<Solar> result = _solarService.ViewByKey(SectionKey,row, column);
            if (result.Success)
            {
                ConsoleIO.DisplaySolar(result.Data);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        
        private void AddPanel()
        {
            Solar solar = ConsoleIO.PromptUserSolar("Add new Panel");
            Result result = _solarService.CreatePanel(solar);
            if (result.Success)
            {
                ConsoleIO.Display(result.Message);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        private void UpdatePanel()
        {
               ConsoleIO.Display("Update a panel");
                ConsoleIO.Display("Enter Panel location:");
                String SectionKey = ConsoleIO.PromptUser("Enter Section: ");
                int row = ConsoleIO.PromptInt("Enter Row: ");
                int column = ConsoleIO.PromptInt("Enter Column: ");
                Result<Solar> result = _solarService.ViewByKey(SectionKey, row, column);
                ConsoleIO.Display("Editing" + SectionKey +"-"+ row +"-"+ column);
                 String material = ConsoleIO.PromptUser("");
                 DateTime date = ConsoleIO.PromptUserDate("");
                 bool track = (ConsoleIO.PromptBool(""));
            Solar newPanel = new Solar();
            newPanel.Material = material;
            newPanel.YearCompleted = date;
            newPanel.IsTracking = track;

            _solarRepository.UpdateSolar(result.Data, );

                  
        }

        private void DeletePanel()
        {
            
            
        }
        
        private void ViewBySection()
        {

        }

        
    }
}
