﻿using System;
namespace SolarFarms.UI
{
    public class SolarServiceFactory
    {
        public SolarServiceFactory()
        {
        }
    }
}
