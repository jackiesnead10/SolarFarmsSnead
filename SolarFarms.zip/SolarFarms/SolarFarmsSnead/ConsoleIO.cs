﻿using System;
using SolarFarms.CORE;
namespace SolarFarms.UI
{
    public static class ConsoleIO
    {
        public static void Display(string prompt)
        {
            Console.WriteLine(prompt);
        }

        public static string PromptUser(string prompt)
        {
            string output;
            do
            {
                Console.WriteLine(prompt);
                output = Console.ReadLine();
            } while (string.IsNullOrEmpty(output.Trim()));
            return output;
        }
        public static bool PromptBool(bool prompt)
        {
            bool value = false;
            bool valid = false;
            do
            {
                Console.WriteLine("Enter yes or no: ");
                var inputString = Console.ReadLine();
                if (String.IsNullOrEmpty(inputString))
                {
                    continue;
                }
                if (string.Equals(inputString, "yes"))
                {
                    value = true;
                    valid = true;
                }
                else if (string.Equals(inputString, "no"))
                {
                    value = false;
                    valid = true;
                }

            } while (!valid);

            return value;
        }

        public static Solar PromptUserSolar(string prompt)
        {
            Solar insolar = new Solar();
            insolar.Title = PromptUser("Please enter a new panel:");
            insolar.Created = DateTime.Now;
            return insolar;
        }

        public static int PromptInt(string prompt)
        {
            int output;
            bool valid;
            do
            {
                valid = int.TryParse(PromptUser(prompt), out output);
            } while (!valid);
            return output;
        }

        public static int PromptInt(string prompt, int min, int max)
        {
            int output;
            do
            {
                output = PromptInt(prompt);
            } while (output < min || output > max);
            return output;
        }

        public static DateTime PromptUserDate(string prompt)
        {
            DateTime output;
            do
            {
            } while (!DateTime.TryParseExact(PromptUser(prompt), "MM/dd/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out output));
            return output;
        }

        public static void DisplaySolar(Solar insolar)
        {
            Display($"{Solar.Id} {Solar.Title} {Solar.Created.ToShortDateString()} - {Solar.Completed.ToShortDateString()}");
        }

        public static void DisplayError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        public static DateTime PromptUserDate(string prompt, DateTime max)
        {
            DateTime output;
            do
            {
                output = PromptUserDate(prompt);
            } while (output >= max);
            return output;
        }

        public static void PrintDate(string message, DateTime date)
        {
            Console.WriteLine($"{message}{date.ToString()}");
        }

        public static void PrintDateDifference(string message, TimeSpan difference)
        {
            Console.WriteLine($"{difference.Hours}{message}");
        }

        public static void DisplaySolars(List<Solar> Solars)
        {
            foreach (var Solar in Solars)
            {
                Display($"{Solar.Id} {Solar.Title} {Solar.Completed.ToShortDateString()}");
            }
        }
    }
}
