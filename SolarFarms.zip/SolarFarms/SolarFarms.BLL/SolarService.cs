﻿using System;
using System.Collections.Generic;
using SolarFarms.CORE;

namespace SolarFarms.BLL
{
    public class SolarService
    {
        private ISolarRepository _SolarRepository;

        public SolarService(SolarRepository SolarRepository)
        {
            _SolarRepository = SolarRepository;
        }

        public Result<Solar> AddSolar(Solar insolar)
        {
            //TODO: Put in validation for Solars
            Result<Solar> result = new Result<Solar>();

            if (string.IsNullOrEmpty(Solar.Title))
            {
                result.Message = "Solar panel is required";
                result.Success = false;
                return result;
            }

            result.Success = true;
            result.Message = "Created Solar panel Successfully";
            _SolarRepository.AddSolar(Solar);
            return result;
        }

        public List<Solar> ViewAll()
        {
            return _SolarRepository.ReadAllSolars();
        }

        public Result<Solar> ViewByKey(string SectionKey, int row,int column)
        {
            Solar solar = _SolarRepository.ViewByKey(SectionKey, row, column);
            Result<Solar> result = new Result<Solar>();
            if (solar == null)
            {
                result.Success = false;
                result.Message = $"Solar Id: "+ SectionKey +" " + row + " "+  column + "was not found";
            }
            else
            {
                result.Success = true;
                result.Data = solar;
            }
            return result;
        }
    }
}
