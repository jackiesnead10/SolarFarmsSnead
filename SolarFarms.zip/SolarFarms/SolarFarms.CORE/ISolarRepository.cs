﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public interface ISolarRepository
    {
        /// <summary>
        /// Add the task to a storage, and assign an id to it
        /// </summary>
        /// <param name="task"></param>
        /// <returns></returns>
        Solar Add(Solar solfa);

        List<Solar> ViewAll();
        Solar ViewBySection(string SectionKey);
        Solar ViewByKey(string SectionKey, int row, int column);
        void UpdateSolar(int id, Solar solfa);
        void DeleteSolar(int id);
    }
}
