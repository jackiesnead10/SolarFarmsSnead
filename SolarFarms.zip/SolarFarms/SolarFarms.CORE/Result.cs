﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public class Result<T>
    {
        // +Message :string
        //  +Success : bool
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
    }
}
