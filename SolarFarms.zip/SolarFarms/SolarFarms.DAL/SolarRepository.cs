﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolarFarms.CORE;
using System.IO;

namespace SolarFarms.DAL
{
    public class SolarRepository : ISolarRepository
    {
        private string _fileName = "Solardata.csv";
        private Dictionary<String,List<Solar>> _Solars;
        public SolarRepository()
        {
            
            _Solars = new Dictionary<String,List<Solar>>();
            if (!File.Exists(_fileName))
            {
                File.Create(_fileName);
            }
            else
            {
                using (StreamReader sr = new StreamReader(_fileName))

                    // ID, TItle, Created, Completed
                    // 1,Find Diamonds,1/1/2021,4/14/2021
                    // fields[0] = "1"
                    // fields[1] = "Find Diamonds"
                    // fields[2] = "1/1/2021"
                    // fields[3] = "1/1/2021"
                    for (string line = sr.ReadLine(); line != null; line = sr.ReadLine())
                    {
                        string[] fields = line.Split(',');
                        Solar solar = new Solar();
                        solar.Section = fields[0];
                        solar.Row = int.Parse(fields[1]);
                        solar.Column = int.Parse(fields[2]);
                        solar.Material = fields[3];
                        solar.YearCompleted = DateTime.Parse(fields[4]);
                        solar.IsTracking = bool.Parse(fields[5]);
                        if (_Solars.ContainsKey(solar.Section))
                        {
                            _Solars[solar.Section].Add(solar);
                        }
                        else
                        {
                            _Solars.Add(solar.Section, new List<Solar>());
                            _Solars[solar.Section].Add(solar);
                        }
                        // change any list lookups with dictionary lookup
                    }
            }

        }
        private SolarsResult ViewBySection(String sectionKey)
        {
           
            SolarsResult result = new SolarsResult();

            /*
            foreach (var Solar in _Solars)
            {
                if (sectionKey == Solar.Section)
                {
                    result.Data.Add(Solar);

                }
            }

            */
            result.Data = _Solars[sectionKey];
                return result ;
                
         }
        
        private void SaveSolars()
        {
            if (File.Exists(_fileName))
            {
                using (StreamWriter sw = new StreamWriter(_fileName))
                {
                    
                    foreach (var key in _Solars.Keys)
                    {
                        foreach(var Solar in _Solars[key])
                        sw.WriteLine($"{Solar.Section},{Solar.Row},{Solar.Column},{Solar.Material},{Solar.YearCompleted.ToShortDateString()},{Solar.IsTracking}");
                  
                }
            }
        }
        public void CreateSolar(Solar Solar)
        {
            _Solars.Add(Solar);
            SaveSolars();
        }
        


        public List<Solar> ViewAll()
        {
            return _Solars;
        }

        public Solar ViewByKey(String sectionKey, int row, int column)
        {
            foreach (var Solar in _Solars[sectionKey])
            {
                
                
                    if(row == Solar.Row)
                    {
                        if(column == Solar.Column)
                        {
                            return Solar;
                        }
                    }
                    
               
            }
            return null;
        }

        public void UpdateSolar(Solar oldSolar, Solar newSolar)
        {
            int index;
            index = _Solars.IndexOf(oldSolar);
            _Solars[index] = newSolar;
            SaveSolars();
        }

        public void DeleteSolar(Solar solar)
        { 
            _Solars.Remove(solar);
            SaveSolars();
        }
    }
}

