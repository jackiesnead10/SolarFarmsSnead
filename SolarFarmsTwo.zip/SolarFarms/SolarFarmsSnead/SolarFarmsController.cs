﻿using System;
using SolarFarms.CORE;
using SolarFarms.BLL;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolarFarms.UI;
using SolarFarms.DAL;
namespace SolarFarms.SolarFarms.UI
{
    public class SolarFarmsController
    {
        private SolarService _solarService;
       // public SolarRepository _solarRepository = new SolarRepository();
        public SolarFarmsController(SolarService solarService)
        {
            _solarService = solarService;
        }
        public void Run()
        {
            // Keep the application running, display a menu for CRUD of tasks
            ConsoleIO.Display("Welcome to the Solar Farm.");
            ConsoleIO.Display("===========================");
            do
            {


                int choice = ConsoleIO.PromptInt("0. Exit\n1. Add Panel\n2. View Panels\n3. Find Panel\n4. Update Panel\n5. Delete Panel", 0, 5);
                switch (choice)
                {
                    case 0:
                        ConsoleIO.Display("Good bye");
                        return;
                    case 1:
                        AddPanel();
                        break;
                    case 2:
                        ViewBySection();
                        break;
                    case 3:
                        FindPanel();
                        break;
                    case 4:
                        UpdatePanel();
                        break;
                    case 5:
                        DeletePanel();
                        break;
                }
            } while (true);
        }

        private void FindPanel()
        {
            ConsoleIO.Display("Enter Panel location:");
            String SectionKey = ConsoleIO.PromptUser("Enter Section: ");
            int row = ConsoleIO.PromptInt("Enter Row: ",1, 250);
            int column = ConsoleIO.PromptInt("Enter Column: ",1 ,250);
            Result<Solar> result = _solarService.ViewByKey(SectionKey,row, column);
            if (result.Success)
            {
                ConsoleIO.DisplaySolar(result.Data);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        
        private void AddPanel()
        {
            Solar solar = ConsoleIO.PromptUserSolar("Add new Panel");
            Result<Solar> result = _solarService.AddSolar(solar);
            if (result.Success)
            {
                ConsoleIO.Display(result.Message);
            }
            else
            {
                ConsoleIO.DisplayError(result.Message);
            }
        }

        private void UpdatePanel()
        {
               ConsoleIO.Display("Update a panel");
                ConsoleIO.Display("Enter Panel location:");
                String SectionKey = ConsoleIO.PromptUser("Enter Section: ");
                int row = ConsoleIO.PromptInt("Enter Row: ", 1, 250);
                int column = ConsoleIO.PromptInt("Enter Column: ", 1, 250);
                Result<Solar> result = _solarService.ViewByKey(SectionKey, row, column);

            if (result.Success == false)
            {
                ConsoleIO.Display("Panel Does Not Exist, please try again with a real Panel:");

            }
            else
            {
                ConsoleIO.Display(" Editing" + SectionKey + "-" + row + "-" + column);
                PanelMaterial material = ConsoleIO.PromptEnum("What is new panel material:");
                DateTime date = ConsoleIO.PromptUserDate("What is the new panel installation date:");
                bool track = ConsoleIO.PromptBool("Is tracking?");
                Solar newPanel = new Solar();
                newPanel.Section = SectionKey;
                newPanel.Row = row;
                newPanel.Column = column;
                newPanel.Material = material;
                newPanel.YearCompleted = date;
                newPanel.IsTracking = track;

                result = _solarService.UpdatePanel(result.Data, newPanel);
                ConsoleIO.Display(result.Message);
            }
            
           /* _solarRepository.UpdateSolar(result.Data, );
            {

            }
           */
                  
        }

        private void DeletePanel()
        {
            String SectionKey = ConsoleIO.PromptUser("Enter Section:");
            int row = ConsoleIO.PromptInt("Enter Row: ", 1, 250);
            int column = ConsoleIO.PromptInt("Enter Column: ",1, 250);
            Solar oldSolar = new Solar();
            oldSolar.Section = SectionKey;
            oldSolar.Row = row;
            oldSolar.Column = column;

            _solarService.DeleteByPanel(oldSolar);

            ConsoleIO.Display("Success panel deleted!");

        }
        
        private void ViewBySection()
        {
            string sectionName = ConsoleIO.PromptUser("enter a Section");
            
            List<Solar> solar = _solarService.ViewBySection(sectionName);
            if(solar == null)
            {
                ConsoleIO.Display("Section does not exist!");
            }
            else
            {
                ConsoleIO.DisplaySolars(solar);
            }
            

        }


    }
}
