﻿using System;
using SolarFarms.CORE;
using SolarFarms.DAL;
using SolarFarms.BLL;
using SolarFarms.SolarFarms.UI;
using SolarFarms.UI;


namespace SolarFarms
{
    class Program
    {
       static void Main(string[] args)
        {
            //make solar.csv
            

            SolarRepository repository = new SolarRepository();
            SolarService service = SolarServiceFactory.GetSolarService(repository);
            SolarFarmsController controller = new SolarFarmsController(service);
            controller.Run();

        }
    }
    
}
