﻿using System;
using SolarFarms.CORE;
using System.Collections.Generic;

namespace SolarFarms.UI
{
    public static class ConsoleIO
    {
        public static void Display(string prompt)
        {
            Console.WriteLine(prompt);
        }

        public static string PromptUser(string prompt)
        {
            string output;
            do
            {
                Console.WriteLine(prompt);
                output = Console.ReadLine();
            } while (string.IsNullOrEmpty(output.Trim()));
            return output;
        }
        public static bool PromptBool(string prompt)
        {
            bool value = false;
            bool valid = false;
            do
            {
                Console.WriteLine(prompt);
                Console.WriteLine("Enter yes or no: ");
                var inputString = Console.ReadLine();
                if (String.IsNullOrEmpty(inputString))
                {
                    continue;
                }
                if (string.Equals(inputString, "yes"))
                {
                    value = true;
                    valid = true;
                }
                else if (string.Equals(inputString, "no"))
                {
                    value = false;
                    valid = true;
                }

            } while (!valid);

            return value;
        }
        // double check insolar.section and year completed
        // add user input for row and column
        // add material input
        // add installation year input
        //add is tracked yes/no? input
        public static Solar PromptUserSolar(string prompt)
        {
            Solar insolar = new Solar();
            insolar.Section = PromptUser("Please enter a new panel:");
            insolar.Row =  PromptInt("Enter row number: (1-250)", 1, 250);
            insolar.Column = PromptInt("Enter column number: (1-250)", 1, 250);
            insolar.Material = PromptEnum("What is the panel material:");
            insolar.YearCompleted = PromptUserDate("Installation date?:");
            insolar.IsTracking = PromptBool("Is it being tracked");
            //insolar.YearCompleted = DateTime.Now;
            return insolar;
        }

        public static int PromptInt(string prompt)
        {
            int output;
            bool valid;
            do
            {
                valid = int.TryParse(PromptUser(prompt), out output);
            } while (!valid);
            return output;
        }

        public static int PromptInt(string prompt, int min, int max)
        {
            int output;
            do
            {
                output = PromptInt(prompt);
            } while (output < min || output > max);
            return output;
        }
        // Do I need Prompt User Date?
        public static DateTime PromptUserDate(string prompt)
        {
            DateTime output;
            do
            {
            } while (!DateTime.TryParse(PromptUser(prompt), out output ));
            return output;
        }

        public static PanelMaterial PromptEnum(string prompt)
        {
            //check Enum logic
            PanelMaterial materialChoice;
            //PanelMaterial materialChoice = PanelMaterial.GIGS


            
            while(true)
            {
                Display(prompt);
                string response = Console.ReadLine();
                if(Enum.TryParse<PanelMaterial>(response, true, out materialChoice))
                {
                    return materialChoice;
                }

               
                Console.Write("[ERR]\n Must be one of the following materials:");
                foreach(PanelMaterial material in Enum.GetValues(typeof(PanelMaterial)))
                {
                    Console.Write(material.ToString().ToLower() + " ");
                }
                Console.WriteLine(" Success");




            }
           

        }
        // check the method above
        public static void DisplaySolar(Solar insolar)
        {
            Display($"{insolar.Section} {insolar.Row} {insolar.Column} - {insolar.YearCompleted.ToShortDateString()}");
        }
        // do I need Display Solar?

        public static void DisplayError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }

        public static DateTime PromptUserDate(string prompt, DateTime max)
        {
            DateTime output;
            do
            {
                output = PromptUserDate(prompt);
            } while (output >= max);
            return output;
        }

        public static void PrintDate(string message, DateTime date)
        {
            Console.WriteLine($"{message}{date.ToString()}");
        }

        public static void PrintDateDifference(string message, TimeSpan difference)
        {
            Console.WriteLine($"{difference.Hours}{message}");
        }

        public static void DisplaySolars(List<Solar> Solars)
        {
            foreach (var Solar in Solars)
            {
                Display($"{Solar.Section} {Solar.Row} {Solar.Column} {Solar.Material} {Solar.YearCompleted.ToShortDateString()}");
            }
        }
    }
}
