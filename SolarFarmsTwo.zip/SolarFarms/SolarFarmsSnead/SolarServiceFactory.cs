﻿using System;
using SolarFarms.BLL;
using SolarFarms.CORE;


namespace SolarFarms.UI
{
    public class SolarServiceFactory
    {
        public static SolarService GetSolarService (ISolarRepository _SolarRepository)
        {
            SolarService solserve = new SolarService(_SolarRepository);

            return solserve;
        }
    }
}
