using NUnit.Framework;
using SolarFarms.BLL;
using SolarFarms.CORE;
using SolarFarms.DAL;
using System.Collections.Generic;
using SolarFarms.BLL.TEST;

namespace SolarFarm.BLL.TEST
{
    public class Tests
    {
        SolarService service;

        [SetUp]
        public void Setup()
        {
            service = new SolarService(new MockRepository());

        }


        [Test]
        public void ShouldNotAddEmptySection()
        {
            Solar solar = new Solar();
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;
            Result<Solar> result = service.AddSolar(solar);



            Assert.IsFalse(result.Success);

        }
        [Test]
        public void ShouldAdd()
        {
            Solar solar = new Solar();
            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;
            Result<Solar> result = service.AddSolar(solar);



            Assert.IsTrue(result.Success);
        }
            [Test]
            public void ShouldUpdate()
            {
                Solar solar = new Solar();
                solar.Section = "Sun";
                solar.Row = 1;
                solar.Column = 2;
                solar.Material = PanelMaterial.Copper;

                 Solar newsolar = new Solar();
                 solar.Section = "Sun";
                 solar.Row = 1;
                 solar.Column = 2;
                 solar.Material = PanelMaterial.CIGS;
                 Result<Solar> result = service.UpdatePanel(solar, newsolar);



                Assert.IsTrue(result.Success);

            }
        [Test]
        public void ShouldFindByKey()
        {
            Solar solar = new Solar();
        

            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;
            Result<Solar> findsolar = service.ViewByKey(solar.Section, solar.Row, solar.Column);

            Assert.IsTrue(findsolar.Success);
        }

        [Test]
        public void ShouldFindBySection()
        {
            string sectionname = "Sun";
           List<Solar> findsection = service.ViewBySection(sectionname);

            Assert.NotNull(findsection);
        }
        [Test]
        public void ShouldNotUpdateEmptySection()
        {
            Solar solar = new Solar();
            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;

            Solar newsolar = new Solar();
            solar.Section = " ";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.CIGS;
            Result<Solar> result = service.UpdatePanel(solar, newsolar);




            Assert.IsFalse(result.Success);
        }




        }
    }