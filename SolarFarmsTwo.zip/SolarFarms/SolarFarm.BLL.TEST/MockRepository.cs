﻿using System;
using System.Collections.Generic;
using SolarFarms.CORE;
using System.Linq;

namespace SolarFarms.BLL.TEST
{
    public class MockRepository: ISolarRepository
    {
        List<Solar> solarmock = new List<Solar>();
      
        public MockRepository()
        {

            Solar solar = new Solar();
            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;
            solarmock.Add(solar);

            solar = new Solar();
            solar.Section = "Sun";
            solar.Row = 3;
            solar.Column = 4;
            solar.Material = PanelMaterial.GIGS;
            solarmock.Add(solar);
        }

        public void AddSolar(Solar insolar)
        {
           
        

          }

    public bool DeleteSolar(Solar panel)
        {
            return true;
        }

        public Result<Solar> UpdateSolar(Solar oldSolar, Solar newSolar)
        {
            Result<Solar> result = new Result<Solar>();


           
            result.Success = true;
            result.Message = "Success: panel has been updated";
            return result;
        }

        public Solar ViewByKey(string SectionKey, int row, int column)
        {
            return solarmock.FirstOrDefault(p => p.Section == SectionKey && p.Row == row && p.Column == column);
            
        }

        public List<Solar> ViewBySection(string SectionKey)
        {
            return solarmock.Where(p => p.Section == SectionKey).ToList();
        }
    }
}
