using NUnit.Framework;
using SolarFarms.DAL;
using SolarFarms.CORE;
using System.Collections.Generic;

namespace SolarFarms.DAL.TEST
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            Solar solar = new Solar();
            SolarRepository repo = new SolarRepository();

            solar.Section = "Moon";
            solar.Row = 2;
            solar.Column = 3;
            solar.Material = PanelMaterial.Copper;

            repo.AddSolar(solar);
        }

        [Test]
        public void ShouldAddPanel()
        {
            Solar solar = new Solar();
            SolarRepository repo = new SolarRepository();

            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;

            repo.AddSolar(solar);
            Solar view = repo.ViewByKey("Sun", 1, 2);



            Assert.IsNotNull(view);

        }
        [Test]
        public void ShouldUpdatePanel()
        {
            //work on this
            Solar solar = new Solar();
            SolarRepository repo = new SolarRepository();

            solar.Section = "Moon";
            solar.Row = 2;
            solar.Column = 3;
            solar.Material = PanelMaterial.Copper;

            repo.DeleteSolar(solar);
            Solar view = repo.ViewByKey("Moon", 2, 3);
            Assert.Pass();



        }






        [Test]
        public void ShouldViewByKey()
        {
            //arrange
            SolarRepository solarrepo = new SolarRepository();
            //act
            Solar solar = solarrepo.ViewByKey("mars", 2, 2);
            //assert
            Assert.IsNotNull(solar);

        }

        [Test]
        public void ShouldDeletePanel()
        {
            Solar solar = new Solar();
            SolarRepository repo = new SolarRepository();

            solar.Section = "Sun";
            solar.Row = 1;
            solar.Column = 2;
            solar.Material = PanelMaterial.Copper;

            repo.DeleteSolar(solar);
            Solar view = repo.ViewByKey("Sun", 1, 2);
            Assert.Pass();



        }
        [Test]
        public void ShouldViewBySection()
        {
            //arrange
            SolarRepository solarrepo = new SolarRepository();
          
            List<Solar> solarkey = new List<Solar>();
            //act
            solarkey = solarrepo.ViewBySection("mars");
            //assert
            Assert.IsNotNull(solarkey);

        }

        



    }
}