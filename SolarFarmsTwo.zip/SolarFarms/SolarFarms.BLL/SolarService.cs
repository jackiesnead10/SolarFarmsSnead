﻿using System;
using System.Collections.Generic;
using SolarFarms.CORE;

namespace SolarFarms.BLL
{
    public class SolarService
    {
        private ISolarRepository _SolarRepository;

        public SolarService(ISolarRepository SolarRepository)
        {
            _SolarRepository = SolarRepository;
        }

        public Result<Solar> AddSolar(Solar insolar)
        {
            //TODO: Put in validation for Solars
            Result<Solar> result = new Result<Solar>();

            if (string.IsNullOrEmpty(insolar.Section))
            {
                result.Message = " Solar panel is required";
                result.Success = false;
                return result;
            }

            result.Success = true;
            result.Message = "Created Solar panel Successfully";
            _SolarRepository.AddSolar(insolar);
            return result;
        }
        public bool DeleteByPanel(Solar solar)
        {
            return _SolarRepository.DeleteSolar(solar);
        }

        public List<Solar> ViewBySection(string section)
        {
            return _SolarRepository.ViewBySection(section);
            // Add messgae for empty section name
           /* Result<Solar> result = new Result<Solar>();

            if (string.IsNullOrEmpty(section))
            {
                result.Message = " Solar panel is required";
                result.Success = false;
                return result;
            }
            return _SolarRepository.UpdateSolar(solar, newsolar);
           */
        }

        public Result<Solar> ViewByKey(string SectionKey, int row, int column)
        {
            Solar solar = _SolarRepository.ViewByKey(SectionKey, row, column);
            Result<Solar> result = new Result<Solar>();
            if (solar == null)
            {
                result.Success = false;
                result.Message = $"Solar Id: " + SectionKey + " " + row + " " + column + " was not found";
            }
            else
            {
                result.Success = true;
                result.Data = solar;
            }
            return result;
        }
        public Result<Solar> UpdatePanel(Solar solar, Solar newsolar)
        {
            Result<Solar> result = new Result<Solar>();
            
            if (string.IsNullOrEmpty(newsolar.Section))
            {
                result.Message = " Solar panel is required";
                result.Success = false;
                return result;
            }
            return _SolarRepository.UpdateSolar(solar, newsolar);
        }
       


        

           
            

        
    }
}
