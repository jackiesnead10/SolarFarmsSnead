﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public class SolarsResult
    {
        public List<Solar> Data { get; set; }
        public String Message { get; set; }
        public bool Success { get; set; }
        public SolarsResult()
        {
            //  +Data : List<Solar>

        }
    }
}
