﻿using System;
namespace SolarFarms.CORE
{
    public enum PanelMaterial
    {
        CIGS,
        GIGS,
        PolySi,
        CdTe,
        Copper
    }
}
