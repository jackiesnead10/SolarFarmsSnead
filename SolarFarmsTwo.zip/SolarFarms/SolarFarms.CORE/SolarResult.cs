﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public class SolarResult
    {
        public Solar Data { get; set; }
       
        
      //  SolarResult: Result
       //  + Data : Solar
       

        
    }
    
}
