﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public interface ISolarService
    {
        /* +Add(Solar solfa) : SolarResult
         +ViewAll() : SolarsResult
         +ViewSection(string) : SolarResult
         +ViewByKey(string, int, int) : SolarResult
         +Update(Solar solfa) : SolarResult
         +Delete(string, int, int) : Result*/
        
        Result<Solar> Add(Solar solfa);

        List<Solar> ViewAll();
        Solar ViewBySection(string sectionName);
        Solar ViewByKey(string SectionKey, int row, int column);
        void UpdateSolar(int id, Solar solfa);
        bool DeleteSolar(int id);
    }
}
