﻿using System;
using System.Collections.Generic;
namespace SolarFarms.CORE
{
    public class Solar
    {
        public string Section { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
        // public string Material { get; set; }
        public PanelMaterial Material {get; set;}
        public bool IsTracking { get; set; }
        public DateTime YearCompleted { get; set; }
        //check on solar data
        //materials need to use enum
       

    }
}
